import React from 'react'
import '../index.css'
export default function Subscribe(){return (<div><h1>Subscribe</h1><p>Подпишитесь, чтобы получать новости о релизах и концертах.</p><form onSubmit={(e)=>{e.preventDefault();alert('Thank you for subscribing!')}}><input required placeholder='Email'/><button>Subscribe</button></form></div>)}
