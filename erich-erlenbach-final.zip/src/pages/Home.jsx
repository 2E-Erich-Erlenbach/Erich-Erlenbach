import React from 'react'
export default function Home(){return (<div><h1>Главная</h1><p>Добро пожаловать на сайт Erich Erlenbach.</p></div>)}
