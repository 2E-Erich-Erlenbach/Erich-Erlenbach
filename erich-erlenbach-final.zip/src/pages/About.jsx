import React from 'react'
export default function About(){return (<div><h1>Обо мне — Erich Erlenbach</h1><p>Erich Erlenbach - автор, поэт, писатель, композитор и продюсер. Музыка, дизайн и видео.</p></div>)}
