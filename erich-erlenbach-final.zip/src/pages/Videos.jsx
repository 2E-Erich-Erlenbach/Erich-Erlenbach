import React from 'react'
export default function Videos(){return (<div><h1>Видео</h1><div><iframe src='https://www.youtube.com/embed/oypVfXYRDzI' width='560' height='315' title='yt'></iframe></div><div style={{marginTop:12}}><iframe src='https://rutube.ru/play/embed/92796c5474132068500684cda8bff8f2/' width='560' height='315' title='rt'></iframe></div></div>)}
