import React from 'react'
export default function Contact(){return (<div><h1>Контакты</h1><p>Email: you@example.com</p></div>)}
