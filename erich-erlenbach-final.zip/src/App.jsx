import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import About from './pages/About'
import Videos from './pages/Videos'
import Subscribe from './pages/Subscribe'
import Contact from './pages/Contact'
export default function App(){
  return (<div><header style={{padding:20,display:'flex',justifyContent:'space-between'}}><div><strong>Erich Erlenbach</strong></div><nav><Link to='/'>Home</Link> | <Link to='/videos'>Videos</Link> | <Link to='/subscribe'>Subscribe</Link> | <Link to='/about'>About</Link></nav></header><main style={{padding:20}}><Routes><Route path='/' element={<Home/>}/><Route path='/videos' element={<Videos/>}/><Route path='/subscribe' element={<Subscribe/>}/><Route path='/about' element={<About/>}/><Route path='/contact' element={<Contact/>}/></Routes></main></div>)
}
